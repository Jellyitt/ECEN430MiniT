# rosproxy

Due to a naming conflict with an older ROS package, rosproxy has been renamed [rosabridge](https://github.com/ecostech/rosabridge.git). All future maintenance will take place on the new repository.

Thanks!

## Authors

* **Chad Attermann** - *Initial work* - [Ecos Technologies](https://github.com/ecostech)

## License

This project is licensed under the BSD License.

